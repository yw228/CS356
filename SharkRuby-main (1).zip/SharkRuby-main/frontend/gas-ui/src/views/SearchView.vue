<script setup>
import Discover from '../components/Discover.vue';
</script>

<template>
<Discover></Discover>
</template>
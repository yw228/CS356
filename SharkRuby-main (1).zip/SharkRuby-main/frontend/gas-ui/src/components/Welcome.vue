<script setup>

</script>


<template>
    <div class="base">
        <img class="logo" src="@/assets/Costco_logo.png" />

        <p class="emphasis">
            Gas is expensive, Let's find the Cheapest.
        </p>

        <p>
            Shark Ruby is better at quickly way showing fuel prices for Costco.
        </p>
    </div>
</template>


<script>

</script>


<style>
    .logo {
        max-width: 440px;
        margin: auto;
        width: 80%;
    }
    
    .base {
        width: 100%;
        text-align: center
    }

    p{
        font-family: 'Secular One', sans-serif;
        /* text-align: left; */
    }

    p.emphasis {
        font-size: 20px;
    }

    

</style>
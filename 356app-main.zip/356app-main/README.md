# 356app

Try to load the project in xcode and it will work

I had tried to publish the app on app store but I did not pass the verification from apple
